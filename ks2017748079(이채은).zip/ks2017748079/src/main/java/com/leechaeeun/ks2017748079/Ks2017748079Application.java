package com.leechaeeun.ks2017748079;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ks2017748079Application {

	public static void main(String[] args) {
		SpringApplication.run(Ks2017748079Application.class, args);
	}

}

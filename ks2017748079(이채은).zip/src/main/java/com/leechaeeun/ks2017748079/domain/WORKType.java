package com.leechaeeun.ks2017748079.domain;

public enum WORKType {
    notice("공지사항"),
    free("자유게시판");

    private String value;

    WORKType(String value){
        this.value = value;
    }
    public String getValue(){return value;}
}

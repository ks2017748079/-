package com.leechaeeun.ks2017748079.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.type.BasicType;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;


@Getter
@Setter

@NoArgsConstructor

@Entity
@Table

public class PROFILE implements Serializable {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idx;

    @Column
    @Enumerated(EnumType.STRING)
    private BASICType BASICType;

    @Column
    private String NETWORK;

    @Column
    private String USERNAME;

    @Column
    private String URL;

    @Builder
    public PROFILE( String NETWORK, String USERNAME, String URL){

        this.NETWORK = NETWORK;
        this.USERNAME = USERNAME;
        this.URL = URL;
    }


}

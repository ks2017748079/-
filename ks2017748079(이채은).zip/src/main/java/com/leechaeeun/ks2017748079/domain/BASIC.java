package com.leechaeeun.ks2017748079.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.type.BasicType;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;


@Getter
@Setter

@NoArgsConstructor

@Entity
@Table

public class BASIC implements Serializable {


    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idx;

    @Column
    @Enumerated(EnumType.STRING)
    private BASICType BasicType;

    @Column
    private String NAME;

    @Column
    private String LABEL;

    @Column
    private String EMAIL;

    @Column
    private String PHONE;


    @Builder
    public BASIC(BASICType BasicType, String NAME, String LABEL, String EMAIL, String PHONE){

        this.BasicType = BasicType;
        this.NAME = NAME;
        this.LABEL = LABEL;
        this.EMAIL= EMAIL;
        this.PHONE = PHONE;
    }



}

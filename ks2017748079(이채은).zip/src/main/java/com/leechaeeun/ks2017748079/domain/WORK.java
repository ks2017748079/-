package com.leechaeeun.ks2017748079.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Getter
@Setter

@NoArgsConstructor

@Entity
@Table


public class WORK implements Serializable {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idx;

    @Column
    @Enumerated(EnumType.STRING)
    private WORKType WORKType;

    @Column
    private String COMPANY;

    @Column
    private String POSITION;

    @Column
    private String WEBSITE;

    @Column
    private LocalDateTime STARTDATE;

    @Column
    private LocalDateTime ENDDATE;

    @Column
    private String SUMMRY;


    @Builder
    public WORK(WORKType WORKType,String COMPANY, String POSITION, String WEBSITE, LocalDateTime STARTDATE,LocalDateTime ENDDATE,String SUMMRY){

        this.WORKType = WORKType;
        this.COMPANY = COMPANY;
        this.POSITION = POSITION;
        this.WEBSITE = WEBSITE;
        this.STARTDATE = STARTDATE;
        this.ENDDATE = ENDDATE;
        this.SUMMRY = SUMMRY;
    }
}

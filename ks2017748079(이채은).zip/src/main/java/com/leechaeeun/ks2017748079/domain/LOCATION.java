package com.leechaeeun.ks2017748079.domain;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

@Getter
@Setter

@NoArgsConstructor

@Entity
@Table

public class LOCATION implements Serializable {

    @Id
    @Column
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idx;

    @Column
    @Enumerated(EnumType.STRING)
    private BASICType BASICType;

    @Column
    private String ADDRESS;

    @Column
    private String POSTCODE;

    @Builder
    public LOCATION( BASICType BASICType,String ADDRESS, String POSTCODE){

        this.BASICType = BASICType;
        this.ADDRESS = ADDRESS;
        this.POSTCODE = POSTCODE;
    }

}

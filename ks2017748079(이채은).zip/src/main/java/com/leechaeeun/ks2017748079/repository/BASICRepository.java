package com.leechaeeun.ks2017748079.repository;

import com.leechaeeun.ks2017748079.domain.BASIC;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BASICRepository extends JpaRepository<BASIC,Long> {





}

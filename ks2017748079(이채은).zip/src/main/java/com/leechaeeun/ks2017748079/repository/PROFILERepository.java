package com.leechaeeun.ks2017748079.repository;

import com.leechaeeun.ks2017748079.domain.PROFILE;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PROFILERepository extends JpaRepository<PROFILE,Long> {


}

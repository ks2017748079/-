package com.leechaeeun.ks2017748079.domain;

import com.leechaeeun.ks2017748079.repository.BASICRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;


import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class BASICTest {

    @Autowired
    private BASICRepository basicRepository;
    private BASIC savedBASIC;



    //create
    @Before
    public void init(){
        savedBASIC = basicRepository.save(BASIC.builder()
                .NAME("홍길동")
                .LABEL("웹 프로그래머")
                .EMAIL("홍길동@메일주소.도메인")
                .PHONE("010-1234-5678")
                .build());

    }

    //read
    @Test
    public void testFindBASIC(){
        BASIC foundBASIC = basicRepository.findById(savedBASIC.getIdx()).orElse(null);
        assertThat(foundBASIC.getIdx()).isEqualTo(savedBASIC.getIdx());
    }






}

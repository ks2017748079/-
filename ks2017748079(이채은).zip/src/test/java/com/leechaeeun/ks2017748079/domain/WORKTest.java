package com.leechaeeun.ks2017748079.domain;

import com.leechaeeun.ks2017748079.repository.WORKRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;


import java.time.LocalDateTime;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;


@RunWith(SpringRunner.class)
@DataJpaTest
public class WORKTest {

    @Autowired
    private WORKRepository workRepository;
    private WORK savedWORK;

    @Before
    public void init() {
        savedWORK = workRepository.save(WORK.builder()
                .COMPANY("(주)홍길동")
                .POSITION("개발자 ")
                .WEBSITE("http://www.company.domain")
                .STARTDATE(LocalDateTime.now())
                .ENDDATE(LocalDateTime.now())
                .SUMMRY("...요약")
                .build());

    }

    @Test
    public void testFindWORK(){
        WORK foundWORK = workRepository.findById(savedWORK.getIdx()).orElse(null);
        assertThat(foundWORK.getIdx()).isEqualTo(savedWORK.getIdx());
    }


}

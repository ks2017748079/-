package com.leechaeeun.ks2017748079.domain;

import com.leechaeeun.ks2017748079.repository.LOCATIONRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;


@RunWith(SpringRunner.class)
@DataJpaTest

public class LOCATIONTest {

    @Autowired
    private LOCATIONRepository locationRepository;
    private LOCATION savedLOCATION;

    @Before
    public void init(){
        savedLOCATION = locationRepository.save(LOCATION.builder()
                .ADDRESS("부산광역시 oo구 oo번길 ooo")
                .POSTCODE("12345")
                .build());

    }

    @Test
    public void testFindLOCATION(){
        LOCATION foundLOCATION = locationRepository.findById(savedLOCATION.getIdx()).orElse(null);
        assertThat(foundLOCATION.getIdx()).isEqualTo(savedLOCATION.getIdx());
    }



}

package com.leechaeeun.ks2017748079.domain;


import com.leechaeeun.ks2017748079.repository.PROFILERepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
public class PROFILETest {
    @Autowired
    private PROFILERepository profileRepository;
    private PROFILE savedPROFILE;

    @Before
    public void init(){
        savedPROFILE = profileRepository.save(PROFILE.builder()
                .NETWORK("Twitter")
                .USERNAME("홍길동 ")
                .URL("http://www.twitter.com/홍길동 ")
                .build());

    }

    @Test
    public void testFindPROFIL(){
        PROFILE foundPROFILE = profileRepository.findById(savedPROFILE.getIdx()).orElse(null);
        assertThat(foundPROFILE.getIdx()).isEqualTo(savedPROFILE.getIdx());
    }


}
